<!DOCTYPE html>
  <html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <title>POINT OF SALES</title>
        <link rel="stylesheet" href="<?php echo base_url('themes/tezku-front/tezku-default-theme/css/bootstrap.min.css')?>">
        <link rel="stylesheet" href="<?php echo base_url('themes/tezku-front/tezku-default-theme/css/bootstrap.min.css')?>">
        <link rel="stylesheet" href="<?php echo base_url('themes/tezku-front/tezku-default-theme/css/font-awesome.min.css')?>">
        <link rel="stylesheet" href="<?php echo base_url('themes/tezku-front/tezku-default-theme/css/custom.css')?>">
        <link href="<?php echo base_url('assets/datepicker/datepicker3.css') ?>" rel="stylesheet" type="text/css" />
        <!-- <link href="<?php echo base_url();?>assets/theme/global/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assets/theme/global/plugins/select2/css/select2-bootstrap.min.css" rel="stylesheet" type="text/css" /> -->

        <script src="<?php echo base_url('themes/tezku-front/tezku-default-theme/js/jquery-2.2.4.min.js')?>"></script>
        <!-- <script src="<?php echo base_url();?>assets/theme/global/plugins/select2/js/select2.full.min.js" type="text/javascript"></script> -->
        <script src="<?php echo base_url('themes/tezku-front/tezku-default-theme/js/bootstrap.min.js')?>"></script>
        <script src="<?php echo base_url('themes/tezku-back/king/js/plugins/auto-numeric/autoNumeric-min.js')?>"></script>
        <script src="<?php echo base_url('themes/tezku-back/king/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.min.js')?>"></script>
        <script src="<?php echo base_url('themes/tezku-back/king/js/plugins/bootstrap-datepicker/bootstrap-datepicker.js') ?>" type="text/javascript"></script>
    </head>
  <body>
