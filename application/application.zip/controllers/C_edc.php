<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_edc extends MY_Controller{

  public $tbl = 'm_edc';
  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
  }

  function index(){
    $this->view();
  }

  public function view(){
		$this->check_session();
		$priv = $this->cekUser(9);
		$data = array(
			'aplikasi'		=> $this->app_name,
			'title_page' 	=> 'EDC',
			'title_page2' => 'Master EDC',
			'priv_add'		=> $priv['create'],
			);

		if($priv['read'] == 1){
			$this->open_page('edc/V_edc_list', $data);
		} else {
			$this->load->view('layout/V_404', $data);
		}
	}

  public function loadData(){
    $priv   = $this->cekUser(9);
    $table  = "m_edc a";
		$select = 'a.*, b.bank_nama';
		//LIMIT
		$limit = array(
			'start'  => $this->input->get('start'),
			'finish' => $this->input->get('length')
		);

		$join['data'][] = array(
			'table' => 'm_bank b',
			'join'	=> 'b.bank_id = a.edc_bank',
			'type'	=> 'left'
		);
		//WHERE LIKE
		$where_like['data'][] = array(
			'column' => 'a.edc_nama, b.bank_nama', 'param'	 => $this->input->get('search[value]')
		);
		//ORDER
		$index_order = $this->input->get('order[0][column]');
		$order['data'][] = array(
			'column' => $this->input->get('columns['.$index_order.'][name]'),
			'type'	 => $this->input->get('order[0][dir]')
		);

		$query_total = $this->mod->select($select, $table, $join);
		$query_filter = $this->mod->select($select, $table, $join, NULL, NULL, $where_like, $order);
		$query = $this->mod->select($select, $table, $join, NULL, NULL, $where_like, $order, $limit);

		$response['data'] = array();
		if ($query<>false) {
			$no = $limit['start']+1;

			foreach ($query->result() as $val) {
        $button = '';
        if ($val->edc_status_aktif == 'y') {
          $status = '<span class="label bg-green-jungle bg-font-green-jungle"> Aktif </span>';
          if($priv['update'] == 1)
          {
            $button = $button.'<button class="btn blue-ebonyclay" type="button" onclick="openFormEdc('.$val->edc_id.')" title="Edit">
                      <i class="icon-pencil text-center"></i>
                    </button>';
          }
          if($priv['delete'] == 1)
          {
            $button = $button.'<button class="btn red-thunderbird" type="button" onclick="deleteData('.$val->edc_id.')" title="Non Aktifkan">
            <i class="icon-power text-center"></i>
          </button>';
          }

        } else {
          $status = '<span class="label bg-red-thunderbird bg-font-red-thunderbird"> Non Aktif </span>';
          if($priv['update'] == 1)
          {
            $button = $button.'<button class="btn blue-ebonyclay" type="button" onclick="openFormEdc('.$val->edc_id.')" title="Edit"disabled>
                      <i class="icon-pencil text-center"></i>
                    </button>';
          }
          if($priv['delete'] == 1)
          {
            $button = $button.'<button class="btn green-jungle" type="button" onclick="aktifData('.$val->edc_id.')" title="Aktifkan">
            <i class="icon-power text-center"></i>
            </button>';
          }

        }
				$response['data'][] = array(
					$no,
					$val->edc_nama,
					$val->bank_nama,
          $status,
					$button
				);
				$no++;
			}
		}

		$response['recordsTotal'] = 0;
		if ($query_total<>false) {
			$response['recordsTotal'] = $query_total->num_rows();
		}
		$response['recordsFiltered'] = 0;
		if ($query_filter<>false) {
			$response['recordsFiltered'] = $query_filter->num_rows();
		}

		echo json_encode($response);
  }

  function getForm(){
    $data = array();
    $this->load->view('edc/V_edc_form', $data);
  }

  function loadDataWhere(){
    $id = $this->input->post('id');
    $table  = "m_edc a";
		$select = 'a.*';

		$join['data'][] = array(
			'table' => 'm_bank b',
			'join'	=> 'b.bank_id = a.edc_bank',
			'type'	=> 'left'
		);

    $join['data'][] = array(
			'table' => 'm_cabang c',
			'join'	=> 'c.cabang_id = a.edc_cabang',
			'type'	=> 'left'
		);
		//WHERE LIKE
		$where['data'][] = array(
			'column' => 'a.edc_id',
      'param'	 => $id
		);

    $query = $this->mod->select($select, $table, $join, $where);
    $value = $query->row();
    // echo $this->db->last_query();
      $data = array(
        'edc_id'            => $value->edc_id,
        'edc_nama'          => $value->edc_nama,
        'edc_bank'          => $value->edc_bank,
        'edc_status_aktif'  => $value->edc_status_aktif,
        'edc_create_date'   => $value->edc_create_date,
        'edc_cabang'        => $value->edc_cabang
      );

    echo json_encode($data);

  }

  public function loadData_selectbank($value=''){
    $data = array();
    $query = $this->mod->select_config("m_bank", "")->result();

    foreach ($query as $key => $value) {
      $data[] = array(
        'data_id' => $value->bank_id,
        'data_name' => $value->bank_nama
      );
    }

    echo json_encode($data);

  }

  function loadDataSelectCabang(){
    $data = array();
    $query = $this->mod->select_config("m_cabang", "")->result();

    foreach ($query as $key => $value) {
      $data[] = array(
        'data_id' => $value->cabang_id,
        'data_name' => $value->cabang_nama
      );
    }

    echo json_encode($data);
  }

  function general_post_data($type, $id = null){
		// 1 Insert, 2 Update, 3 Delete / Non Aktif
		if ($type == 1) {
			$data = array(
        'edc_nama'                => $this->input->post('i_edc', TRUE),
        'edc_bank'                => $this->input->post('i_bank', TRUE),
        'edc_status_aktif'        => $this->input->post('edc_status_aktif', TRUE),
				'edc_create_date' 			  => date('Y-m-d H:i:s'),
				'edc_create_by' 			    => $this->session->userdata('user_username'),
				// 'edc_update_date' 				=> date('Y-m-d H:i:s'),
				// 'edc_update_by' 				  => $this->session->userdata('user_username'),,
        'edc_revised'             => 0,
        'edc_cabang'              => $this->input->post('i_edc_cabang')
			);
		} else if ($type == 2) {
			$data = array(
        'edc_nama'                => $this->input->post('i_edc', TRUE),
        'edc_bank'                => $this->input->post('i_bank', TRUE),
        'edc_status_aktif'        => $this->input->post('edc_status_aktif', TRUE),
				'edc_update_date' 				=> date('Y-m-d H:i:s'),
				'edc_update_by' 				  => $this->session->userdata('user_username'),
        'edc_revised'             => 0,
        'edc_cabang'              => $this->input->post('i_edc_cabang')
			);
		} else if ($type == 3) {
			$data = array(
        'edc_status_aktif'        => 'n',
				'edc_update_date' 				=> date('Y-m-d H:i:s'),
				'edc_update_by' 				  => $this->session->userdata('user_username'),
        // 'edc_revised'             => $rev,
        'edc_cabang'              => $this->input->post('i_edc_cabang')
			);
		} else if ($type == 4) {
			$data = array(
        'edc_status_aktif'        => 'y',
				'edc_update_date' 				=> date('Y-m-d H:i:s'),
				'edc_update_by' 				  => $this->session->userdata('user_username'),
        // 'edc_revised'             => $rev,
        'edc_cabang'              => $this->input->post('i_edc_cabang')
			);
		}

		return $data;
	}


  public function postData(){
		$id = $this->input->post('edc_id');
		if (strlen($id)>0) {
			//UPDATE
			$data = $this->general_post_data(2, $id);
			$where['data'][] = array(
				'column' => 'edc_id',
				'param'	 => $id
			);
			$update      = $this->mod->update_data_table($this->tbl, $where, $data);

			if($update->status) {
				$response['status'] = '200';
			} else {
				$response['status'] = '204';
			}

		} else {
			//INSERT
			$data = $this->general_post_data(1);
			$insert = $this->mod->insert_data_table($this->tbl, NULL, $data);
			if($insert->status) {
				$response['status'] = '200';
			} else {
				$response['status'] = '204';
		}

  }
		echo json_encode($response);
	}


}
