<html>
<head>
	<style>
	.gg {
    border:1px solid;
    }
	</style>
</head>
<body>
	<h3 align="left">PT. NUSA INDAH METALINDO</h3>
	<h3 align="center">LAPORAN SISA ORDER PEMBELIAN (PO)</h3>
	<table border="0" width="50%" align="center">
  		<tr>
  			<td width='30%' align="right">Periode</td>
			<td>:</td>
			<td></td>
  		</tr>
	</table>
	<br>
	<table border="1" width="100%" rules="all">
		<tr>
			<td align="center" width="4%">No</td>
			<td align="center" width="13%">No. PO</td>
			<td align="center" width="13%">Tgl PO</td>
			<td align="center" width="13%">Nama Suplier</td>
			<td align="center" width="13%">Artikel</td>
			<td align="center" width="18%">Nama Barang/Jasa</td>
			<td align="center" width="13%">Qty</td>
			<td align="center" width="13%">Satuan</td>
			<td align="center" width="13%">Harga Satuan</td>
			<td align="center" width="13%">Total</td>
			<td align="center" width="13%">Keterangan</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td colspan="9" align="center">Total</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
		</tr>
	</table>
	<br>
	<table border="1" width="30%" rules="all" align="left">
  		<tr>
			<td align="center" width="15%">Diperiksa</td>
			<td align="center" width="15%">Dibuat</td>
  		</tr>
		<tr>
			<td height="7%"></td>
			<td height="7%"></td>
  		</tr>
		<tr>
			<td align="center">Kabah Pembelian</td>
			<td align="center">Staff Pembelian</td>
  		</tr>
	</table>
 </body>
</html>