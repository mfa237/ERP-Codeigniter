<html>

<head>
	<style>
	.gg {
    border:1px solid;
    }
	</style>
</head>

  <body>
  	<table width="100%" border="1" cellspacing="0">
  <tr>
    <td>
      <table align="left" width="42%" border="0">
      <tr>
        <th scope="col"><div align="center">PT. NUSA INDAH METALINDO</div></th>
      </tr>
      <tr>
        <td><div align="center">Jln. Margomulyo 44 JJ No. 3-4, Surabaya</div></td>
      </tr>
      <tr>
        <td><div align="center">Tlp : 031-7494905, 7483889</div></td>
      </tr>
    </table>
      <table align="right" width="40%" border="0">
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td width="4%">No</td>
          <td width="2%">:</td>
          <td width="94%">&nbsp;</td>
        </tr>
        <tr>
          <td>Tgl</td>
          <td>:</td>
          <td>&nbsp;</td>
        </tr>
    </table>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
	<div class ="gg"> </div>
		<h3 align="center">TANDA TERIMA</h3>
	<div class ="gg"> </div>
	<table width="100%" border="0" cellspacing="0">
      <tr>
        <td width="24%">Diterima dari</td>
        <td width="3%">:</td>
        <td width="73%">&nbsp;</td>
      </tr>
      <tr>
        <td>Keterangan </td>
        <td>:</td>
        <td><input type="checkbox" name="checkbox" id="checkbox" /></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td><input type="checkbox" name="checkbox" id="checkbox" /></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td><input type="checkbox" name="checkbox" id="checkbox" /></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td><input type="checkbox" name="checkbox" id="checkbox" /></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
    </table>
    <table width="100%" border="1" cellspacing="0">
      <tr>
        <th scope="col">No.</th>
        <th scope="col">No. Kwitansi</th>
        <th scope="col">No. Surat Jalan</th>
        <th scope="col">No. Invoice</th>
        <th scope="col">No. Faktur pajak</th>
        <th scope="col">Nominal</th>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
    </table>
    <table width="100%" border="0">
      <tr>
        <td width="21%">Kembali Tgl</td>
        <td width="8%">:</td>
        <td width="28%">&nbsp;</td>
        <td width="4%">&nbsp;</td>
        <td width="28%">&nbsp;</td>
        <td width="11%">&nbsp;</td>
      </tr>
      <tr>
        <td>Nota</td>
        <td>:</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td colspan="2">Tukar tanda terima setiap hari</td>
        <td>&nbsp;</td>
        <td>Jam</td>
        <td>&nbsp;</td>
        <td>WIB</td>
      </tr>
    </table>
    <p>&nbsp;</p>
    <table align="left" width="50%" border="1" rules="all">
      <tr>
        <th scope="col">yang menerima</th>
        <th scope="col">yang membuat</th>
      </tr>
      <tr>
        <td height="64">&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td align="center">Verifikasi</td>
      </tr>
    </table>
    <table border="0" align="right" width="40%">
    	<tr>
    		<td>Catatan:</td>
    	</tr>
    	<tr>
    		<td>&nbsp;</td>
    	</tr>
    </table>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    </td>
  </tr>
</table>
    
  </body>
</html>