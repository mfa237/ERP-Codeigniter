<html>
<head>
	<style>
	.gg {
    border:1px solid;
    }
	</style>
</head>
<body>
	<h3 align="left">PT. NUSA INDAH METALINDO</h3>
	<h3 align="center">REKAP KARTU STOK GUDANG BAHAN</h3>
	<table border="0" width="50%" align="center">
  		<tr>
  			<td width='30%' align="right">Periode</td>
			<td>:</td>
			<td></td>
  		</tr>
	</table>
	<br>
	<table border="1" width="100%" rules="all">
		<tr>
			<td rowspan="2" align="center" width="4%">No</td>
			<td rowspan="2" align="center" width="13%">Kode Barang</td>
			<td rowspan="2" align="center" width="18%">Nama Barang</td>
			<td rowspan="2" align="center" width="13%" >Satuan</td>
			<td rowspan="2" align="center" width="13%">Saldo Awal</td>
			<td colspan="3" align="center" width="13%">Masuk</td>
			<td colspan="3" align="center" width="13%">Keluar</td>
			<td rowspan="2" align="center" width="13%">Saldo Akhir</td>
			<td rowspan="2" align="center" width="13%">Keterangan</td>
		</tr>
		<tr>
			<td align="center" width="13%">Beli</td>
			<td align="center" width="13%">Pengembalian Brg</td>
			<td align="center" width="13%">Lain-lain</td>
			<td align="center" width="13%">Pemakaian</td>
			<td align="center" width="13%">Retur Beli</td>
			<td align="center" width="13%">Lain-lain</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td colspan="4" align="center">Total</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
		</tr>
	</table>
	<br>
	<table border="1" width="30%" rules="all" align="left">
  		<tr>
			<td align="center" width="15%">Disetujui</td>
			<td align="center" width="15%">Dibuat</td>
  		</tr>
		<tr>
			<td height="7%"></td>
			<td height="7%"></td>
  		</tr>
		<tr>
			<td align="center">Mgr Operasional</td>
			<td align="center">Gudang Bahan</td>
  		</tr>
	</table>
 </body>
</html>