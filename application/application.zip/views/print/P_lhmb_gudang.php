<html>
<head>
	<style>
	.gg {
    border:1px solid;
    }
	</style>
</head>
 <body>
 <h2 align="Left">PT.NUSA INDAH METALINDO</h2>
 <h3 align="center">LAPORAN HARIAN MASUK BARANG-GUDANG BAHAN</h3>
    <h4 align="center">Tanggal:</h4>
<table border="1" width="100%" rules="all">	
  	<thead>
   		<tr>
		    <td>No</td>	
  			<td>No BPB</td> 
  			<td>Tanggal BPB</td>
  			<td>No.SJ</td>
  			<td>Nama Supplier</td>
  			<td>Group</td>
			<td>Artikel</td>
			<td>Nama Barang</td>
			<td>Qty</td>
			<td>Satuan</td>
			<td>Keterangan</td>
  		</tr>
  	</thead>
  	<tbody>
  		<tr>
  			<td>&nbsp;</td>
  			<td>&nbsp;</td>
  			<td>&nbsp;</td>
  			<td>&nbsp;</td>
  			<td>&nbsp;</td>
  			<td>&nbsp;</td>
			<td>&nbsp;</td>
  			<td>&nbsp;</td>
  			<td>&nbsp;</td>
  			<td>&nbsp;</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
  			<td colspan="8">Total</td>
  			<td>&nbsp;</td>
  			<td>&nbsp;</td>
  			<td>&nbsp;</td>
		</tr>
		
         
  	</tbody>
	</table>
  </table>
<p>&nbsp;</p>
<table border="1" width="40%" rules="all">	
  	<thead>
   		<tr>
		    <td width="20%"><center>Disetujui,</center></td>	
  			<td width="20%"><center>Dibuat,</center></td>
        </tr>
        <tr>
		    <td height=50>&nbsp;</td>	
  			<td>&nbsp;</td>
        </tr>
        <tr>
		    <td><center>Mgr Operasional</center></td>	
  			<td><center>Gudang Bahan</center></td>
        </tr>
 </body>
</html>