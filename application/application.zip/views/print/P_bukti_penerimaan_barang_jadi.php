<html>
<head>
	<style>
	.gg {
    border:1px solid;
    }
	</style>
</head>
 <h2>PT. NUSA INDAH METALINDO</h2>
 <p align="right">No:_____________________</p>
 <p align="right">Tgl:_____________________</p>
 <h3><center>BUKTI PENERIMAAN BARANG JADI</center></h3> 
  <table border="0" width="100%">
        <tr>
  			<td>Nama supplier</td>
			<td width="3">:</td>
			<td width="3">__________________________</td>
  		</tr>
  		<tr>
  			<td>No SJ</td>
			<td width="3">:</td>
			<td width="3">__________________________</td>
  		</tr>
			<tr>
  			<td>No PO</td>
			<td width="3">:</td>
			<td width="3">__________________________</td>
  		</tr>
  		<tr>
  			<td></td>
  			<td></td>
  			<td></td>
  			<td></td>
  			<td></td>
  			<td></td>
  		</tr>
  </table>
  <table border="0" width="100%" height="60" bottom="50" rules="all">	
  	<thead>
   		<tr>
  			<td><center>No</center></td>
  			<td><center>Artikel</center></td>
  			<td><center>Jenis Barang</center></td>
  			<td><center>Qty</center></td>
  			<td><center>Satuan</center></td>
  			<td><center>Harga Barang</center></td>
			<td><center>PPN</center></td>
  			<td><center>Total</center></td>
  			<td><center>Keterangan</center></td>
  		</tr>
	<tr>
  			<td>&nbsp;</td>
  			<td>&nbsp;</td>
			<td>&nbsp;</td>
  			<td>&nbsp;</td>
  			<td>&nbsp;</td>
  			<td>&nbsp;</td>
			<td>&nbsp;</td>
  			<td>&nbsp;</td>
  			<td>&nbsp;</td>
  		</tr>	
  	</thead>
  	<tbody>
  	</tbody>
  </table>
   <table border="0" width="100%">	
     <tr><td>BARANG TERSEBUT DIATAS TELAH DICEK DAN</td>
     </tr>
     <tr><td>DITERIMA DENGAN KONDISI BAIK PADA TANGGAL:</td>
			<td width="3">____________JAM____________________</td>
     </tr>
    </table>
	<table border="0" width="30%" rules="all" valign="bottom" align="left">	
  		<tr>
  			<td align="center">Disetujui,</td>
  			<td align="center">Diperiksa,</td>
			<td align="center">Dibuat,</td>
	    </tr>
		<tr>
  			<td width=3 height=50>&nbsp;</td>
  			<td width=3 height=50>&nbsp;</td>
			<td width=3 height=50>&nbsp;</td>
	    </tr>
		<tr>
  			<td >&nbsp;</td>
			<td align="center">QC</td>
			<td align="center">Gudang BJ</td>
		</tr>
	</tabel>
	<table align="right" width="40%">
		<tr>
			<td align="left">
				Catatan :
			</td>
		</tr>
	</table>
 </body>
</html> 