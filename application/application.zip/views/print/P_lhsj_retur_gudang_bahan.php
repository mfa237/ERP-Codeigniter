<html>
<head>
	<style>
	.gg {
    border:1px solid;
    }
	</style>
</head>
 <body>
 <h2 align="Left">PT.NUSA INDAH METALINDO</h2>
 <h3 align="center">LAPORAN HARIAN SURAT JALAN RETUR-GUDANG BAHAN</h3>
    <h4 align="center">Tanggal:</h4>
  <table border="0" width="100%">
  		<tr>
  			<td></td>
  			<td colspan="2"></td>
  			<td colspan="3"></td>
			<td colspan="2"></td>
  		</tr>
  		<tr>
  			<td></td>
  			<td></td>
  			<td></td>
  			<td></td>
  			<td></td>
  			<td></td>
  		</tr>
  </table>
<p>&nbsp;</p>
<table border="1" width="100%" rules="all">	
  	<thead>
   		<tr>
		    <td align="center">No</td>	
  			<td align="center">No SJR</td>
  			<td align="center">Tanggal SJR</td>
  			<td align="center">Customer/Supplier</td>
  			<td align="center">Kode Barang</td>
  			<td align="center">Nama Barang</td>
			<td align="center">Qty</td>
			<td align="center">Satuan</td>
			<td align="center">Keterangan</td>
  		</tr>
  	</thead>
  	<tbody>
  		<tr>
  			<td>&nbsp;</td>
  			<td>&nbsp;</td>
  			<td>&nbsp;</td>
  			<td>&nbsp;</td>
  			<td>&nbsp;</td>
  			<td>&nbsp;</td>
			<td>&nbsp;</td>
  			<td>&nbsp;</td>
  			<td>&nbsp;</td>
			
  		</tr>
		<tr>
  			<td colspan="6">Total</td>
  			<td>&nbsp;</td>
  			<td colspan="2">&nbsp;</td>
  		</tr>
         
         
  	</tbody>
	</table>
  </table>
<p>&nbsp;</p>
<table border="1" width="40%" rules="all">	
  	<thead>
   		<tr>
		    <td width="20%"><center>Disetujui,</center></td>
          			
  			<td width="20%"><center>Dibuat,</center></td>
        </tr>
        <tr>
		    <td height=50>&nbsp;</td>	
  			<td>&nbsp;</td>
        </tr>
        <tr>
		    <td><center>Mgr Operasional</center></td>	
			<td><center>Gudang Bahan</center></td>
        </tr>
 </body>
</html>