<table class="table table-striped table-bordered table-hover table-checkable order-column" id="default-table-stok">
    <thead>
        <tr>
            <th> No </th>
            <th> Cabang </th>
            <th> Gudang </th>
            <th> Artikel </th>
            <th> Nama Barang </th>
            <th> Jenis Barang </th>
            <th> Minimum Stok </th>
            <th> Stok Gudang </th>
            <th> Satuan Barang </th>
        </tr>
    </thead>
    <tbody>
    </tbody>
</table>